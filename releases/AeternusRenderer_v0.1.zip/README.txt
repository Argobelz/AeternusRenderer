Aeternus Renderer v0.1
======================

1. Place AeternusRenderer.exe anywhere you like and run it.
2. Install the Blender addon:
   Blender > Edit > Preferences > Add-ons > Install
   Select: addon/aeternus_send_job.py

Updates:
   Open the app > Settings > Check Now
   Or enable 'Check automatically on launch'.

NOTE: You must add AeternusRenderer.exe to this folder.
Download it from the GitHub releases page.
